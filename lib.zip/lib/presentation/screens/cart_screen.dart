import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:food_delivery/presentation/screens/checkout_screen.dart';
import 'package:food_delivery/presentation/widgets/custom_button.dart';

import '../blocs/cart_bloc.dart';
import '../blocs/cart_event.dart';
import '../blocs/cart_state.dart';
import '../widgets/app_nav.dart';
import '../widgets/ui_parts.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) => BlocListener<CartBloc, CartState>(
    listenWhen: (previous, current) =>
        previous.items.isNotEmpty && current.items.isEmpty,
    listener: (context, state) => showDemo(context, 'Your cart is empty'),
    child: Scaffold(
      appBar: AppBar(title: const Text('My Cart')),
      bottomNavigationBar: const AppNav(index: 2),
      body: BlocBuilder<CartBloc, CartState>(
        builder: (context, state) => ListView(
          padding: const EdgeInsets.all(18),
          children: [
            if (state.items.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(60),
                  child: Column(
                    children: [
                      Icon(Icons.remove_shopping_cart_outlined, size: 64),
                      Text('Your cart is empty'),
                    ],
                  ),
                ),
              ),
            for (final item in state.items)
              UiCard(
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.network(
                        item.meal.imageUrl,
                        width: 72,
                        height: 72,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) =>
                            const FoodPhoto(width: 72, height: 72),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.meal.name, maxLines: 2),
                          Text('\$${item.meal.price.toStringAsFixed(2)}'),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => context.read<CartBloc>().add(
                        CartDecrease(item.meal.id),
                      ),
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text('${item.quantity}'),
                    IconButton(
                      onPressed: () => context.read<CartBloc>().add(
                        CartIncrease(item.meal.id),
                      ),
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                  ],
                ),
              ),
            const SectionHeading('Order Summary'),
            ListTile(
              title: const Text('Subtotal'),
              trailing: Text('\$${state.subtotal.toStringAsFixed(2)}'),
            ),
            ListTile(
              title: const Text('Delivery Fee'),
              trailing: Text('\$${state.deliveryFee.toStringAsFixed(2)}'),
            ),
            ListTile(
              title: const Text(
                'Total',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Text('\$${state.total.toStringAsFixed(2)}'),
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: 'Proceed to Checkout',
              onPressed: state.items.isEmpty
                  ? null
                  : () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CheckoutScreen()),
                    ),
            ),
          ],
        ),
      ),
    ),
  );
}
