import 'package:flutter/material.dart';

import '../widgets/meal_card.dart';

class FavouritesScreen extends StatelessWidget {
  const FavouritesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Favourites')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: const [
        MealCard(name: 'Grilled Chicken Salad', price: 7.99),
        MealCard(name: 'Margherita Pizza', price: 6.50),
        MealCard(name: 'Chicken Wrap', price: 4.50),
      ],
    ),
  );
}
