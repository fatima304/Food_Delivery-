import 'package:flutter/material.dart';
import '../widgets/app_nav.dart';
import '../widgets/ui_parts.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String query = '';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Explore')),
    bottomNavigationBar: const AppNav(index: 1),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        TextField(
          onChanged: (s) => setState(() => query = s),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'Search meals or vendors',
            border: OutlineInputBorder(),
          ),
        ),
        const SectionHeading('Popular Categories'),
        const Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            GreenTag('Burger'),
            GreenTag('Pizza'),
            GreenTag('Chicken'),
            GreenTag('Seafood'),
            GreenTag('Dessert'),
            GreenTag('Pasta'),
          ],
        ),
        SectionHeading(
          query.isEmpty ? 'Recommended for you' : 'Results for "$query"',
        ),
        // const MealGrid(),
      ],
    ),
  );
}
