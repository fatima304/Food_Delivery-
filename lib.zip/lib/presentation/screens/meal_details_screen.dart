import 'package:flutter/material.dart';
import 'package:food_delivery/presentation/widgets/custom_button.dart';

import '../../core/constants/app_colors.dart';
import '../widgets/ui_parts.dart';

class MealDetailsScreen extends StatefulWidget {
  const MealDetailsScreen({super.key, required this.name, required this.price});
  final String name;
  final double price;
  @override
  State<MealDetailsScreen> createState() => _MealDetailsScreenState();
}

class _MealDetailsScreenState extends State<MealDetailsScreen> {
  int count = 1;
  bool favorite = false;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Meal Details'),
      actions: [
        IconButton(
          onPressed: () => setState(() => favorite = !favorite),
          icon: Icon(
            favorite ? Icons.favorite : Icons.favorite_border,
            color: AppColors.primaryGreen,
          ),
        ),
      ],
    ),
    bottomNavigationBar: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            IconButton(
              onPressed: () => setState(() {
                if (count > 1) count--;
              }),
              icon: const Icon(Icons.remove),
            ),
            Text('$count'),
            IconButton(
              onPressed: () => setState(() => count++),
              icon: const Icon(Icons.add),
            ),
            Expanded(
              child: CustomButton(
                text: 'Add to Cart',
                onPressed: () =>
                    showDemo(context, '$count meal(s) added (UI demo)'),
              ),
            ),
          ],
        ),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const FoodPhoto(height: 260),
        const SizedBox(height: 20),
        Text(
          widget.name,
          style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
        ),
        Text(
          '\$${widget.price.toStringAsFixed(2)}  ★ 4.8 (120)',
          style: const TextStyle(color: AppColors.primaryGreen),
        ),
        const SectionHeading('Description'),
        const Text(
          'Freshly prepared with quality ingredients and delicious flavours.',
        ),
        const SectionHeading('Category'),
        const GreenTag('Main course'),
        const SectionHeading('Origin'),
        const Text('American'),
        const SectionHeading('Instructions'),
        const Text(
          'Prepare fresh ingredients, cook until ready and serve warm. Replace with TheMealDB instructions when connected.',
        ),
      ],
    ),
  );
}
