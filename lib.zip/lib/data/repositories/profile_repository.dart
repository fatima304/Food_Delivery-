import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

class ProfileRepository {
  ProfileRepository(this.auth, this.firestore, this.storage);
  final FirebaseAuth auth;
  final FirebaseFirestore firestore;
  final FirebaseStorage storage;

  User get user {
    final current = auth.currentUser;
    if (current == null) throw StateError('Please sign in first.');
    return current;
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> watchProfile() =>
      firestore.collection('users').doc(user.uid).snapshots();

  Future<void> updateName(String name) async {
    final value = name.trim();
    if (value.isEmpty) throw ArgumentError('Name cannot be empty.');
    final current = user;
    await firestore.collection('users').doc(current.uid).set(
      {'name': value, 'email': current.email, 'updatedAt': FieldValue.serverTimestamp()},
      SetOptions(merge: true),
    );
    await current.updateDisplayName(value);
  }

  Future<void> uploadPhoto(File file) async {
    final current = user;
    final ref = storage.ref().child('profile_photos/${current.uid}/avatar.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    final url = await ref.getDownloadURL();
    await firestore.collection('users').doc(current.uid).set(
      {'photoUrl': url, 'email': current.email, 'updatedAt': FieldValue.serverTimestamp()},
      SetOptions(merge: true),
    );
    await current.updatePhotoURL(url);
  }
}
