import 'data/datasources/biometric_datasource.dart';
import 'data/datasources/device_info_datasource.dart';
import 'presentation/blocs/biometric_cubit.dart';
import 'presentation/blocs/device_info_cubit.dart';
import 'package:food_delivery/presentation/blocs/cart_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:food_delivery/presentation/blocs/meal_details_cubit.dart';
import 'package:dio/dio.dart';
import 'package:food_delivery/services/meal_api_service.dart';
import 'package:food_delivery/core/constants/api_constants.dart';
import 'package:food_delivery/domain/repositories/home_repository.dart';
import 'package:food_delivery/data/repositories/home_repository_impl.dart';
import 'package:food_delivery/presentation/blocs/home_cubit.dart';
import 'package:food_delivery/data/repositories/auth_repository_impl.dart';
import 'package:food_delivery/domain/repositories/auth_repository.dart';
import 'package:food_delivery/presentation/blocs/auth_cubit.dart';
import 'package:food_delivery/services/auth_service.dart';
import 'package:food_delivery/services/firestore_service.dart';

// Dependency Injection setup
final getIt = GetIt.instance;

void setupDependencies() {
  getIt.registerLazySingleton<BiometricDataSource>(() => BiometricDataSource());
  getIt.registerLazySingleton<DeviceInfoDataSource>(() => DeviceInfoDataSource());
  getIt.registerFactory<BiometricCubit>(() => BiometricCubit(getIt<BiometricDataSource>()));
  getIt.registerFactory<DeviceInfoCubit>(() => DeviceInfoCubit(getIt<DeviceInfoDataSource>()));
  // Singleton: one cart instance for the whole authenticated app.
  getIt.registerLazySingleton<CartBloc>(() => CartBloc());
  // Home (TheMealDB)
  getIt.registerLazySingleton<Dio>(
    () => Dio(
      BaseOptions(
        baseUrl: ApiConstants.baseUrl,
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 15),
      ),
    ),
  );
  getIt.registerLazySingleton<MealApiService>(
    () => MealApiService(getIt<Dio>()),
  );
  getIt.registerLazySingleton<HomeRepository>(
    () => HomeRepositoryImpl(getIt<MealApiService>()),
  );
  getIt.registerFactory<HomeCubit>(() => HomeCubit(getIt<HomeRepository>()));

  getIt.registerFactory<MealDetailsCubit>(
    () => MealDetailsCubit(getIt<HomeRepository>()),
  );

  // Services
  getIt.registerLazySingleton<FirestoreService>(() => FirestoreService());

  getIt.registerLazySingleton<AuthService>(() => AuthService());

  // Authentication
  getIt.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(getIt<AuthService>()),
  );

  getIt.registerFactory<AuthCubit>(() => AuthCubit(getIt<AuthRepository>()));
}
